

<html lang="en">

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">	
 
     <!-- Site Metas -->
    <title>Registro</title>  
   
    <!-- Site Icons -->
    

    <!-- Bootstrap CSS -->
    
    <!-- Site CSS -->
 <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
       <link rel="stylesheet" href="../assets/css/style.css"/>
    <!--style>
    #ultimo + div{
        visibility: hidden;
    }
</style-->

</head>
<body  bgcolor="#000000">
    <img class="logo" src="../assets/images/ttr.png"/> 
	<center>
            <div class="row">
                <div class="col-md-12">
                    <div class="contact_form">
                        <h2>Registro</h2>
                        <h5>Datos personales<h5>
              <style>
                  .form-btn3 {
	padding: 0 15px;
	height: 30px;
	font: bold 12px 'Helvetica Neue', Helvetica, Arial, sans-serif;
	text-align: center;
	color: #fff;
	text-shadow: 0 1px 0 rgba(0, 0, 0, 0.7);
	cursor: pointer;
	border: 1px solid #fff;
	outline: none;
	position: relative;
	background-color: #00ff44;
	background-image: -webkit-gradient(linear, left top, left bottom, from(#51ff00), to(#000000)); 
	box-shadow: 1px 2px 4px  #000;/* Saf4+, Chrome */
	
}
              </style>              
                   
 <button  class="form-btn3"  onclick="location.href='../index.html'">Volver a Inicio</button>
 </br>
 </br>
 </br>
<form class="full-box logInForm" name="registrar" action="" id="form1" method="post" onSubmit="return validar()" />
                 
    <?php
    include("registrar3.php")
    ?>     
   <!--?php
  
            $date= date("Y-m-d");
            $nick= limpiar($_POST['nick']);
            $rh= limpiar($_POST['rh']);
            $telefono= limpiar($_POST['telefono']);
            $nacimiento= limpiar($_POST['nacimiento']);
            $copiloto= limpiar($_POST['copiloto']);
            $moto= limpiar($_POST['moto']);
            $placa= limpiar($_POST['placa']);
            $numero= limpiar($_POST['numero']);
            $contacto1= limpiar($_POST['contacto1']);
            $telefono1= limpiar($_POST['telefono1']);
            $mail= limpiar($_POST['mail']);
            $mail= limpiar($_POST['pass']);
            
            
$destinatario = "legionbikers@gmail.com";
$asunto = "Registro Bikers Legion";
$carta = "Buen dia, estos son los datos del nuevo registro en la base de datos de Bikers Legion:
Nombre: $nick \n";
$carta .= "RH: $rh \n";
$carta .= "Telefono: $telefono \n";
$carta .= "Nombre de copiloto: $copiloto \n";
$carta .= "Moto: $moto \n";
$carta .= "Numero de placa: $placa \n";
$carta .= "Numero de moto: $numero \n";
$carta .= "Nombre de contacto: $contacto1 \n";
$carta .= "Telefono1: $telefono1 \n";
$carta .= "Correo: $mail,
Cualquier duda o inquitud no dude en enviar sus comentarios a la pagina https://bikers-legion.000webhostapp.com ,  Gracias por su atencion";

//enviado mensaje
mail($destinatario,$asunto,$carta);
             
          
             
                {
                    $res=$conexion ->query("INSERT INTO admin (fecha,nick,rh,telefono,nacimiento,copiloto,moto,placa,numero,contacto1,telefono1,mail,pass) values ('$date','$nick','$rh','$telefono','$nacimiento','$copiloto','$moto','$placa','$numero','$contacto1','$telefono1','$mail','$pass')");
                    echo '<h4>Te has registrado Correctamente en la base de datos de Bikers Legion</h4>';
                }
  
      
      
?-->

 <div class="col-md-6">
									<div class="form-group">
									   <label for="login_username"></label>  
										<input class="form-control" name="nick" id="nick" type="text" placeholder="Nombres y Apellidos" >
									
									</div>
                                    </div>
                                    <div class="col-md-6">
									<div class="form-group">
									    <label for="login_username"></label> 
										<input class="form-control" name="rh" id="rh" type="text" placeholder="RH" >
									
									</div>
                                    </div>
                                    
                                    <div class="col-md-6">
									<div class="form-group">
										<input class="form-control" name="telefono" id="telefono" type="number" placeholder="Telefono"  >
										
									</div>
                                    </div>
                                    
                                    
                                    
                                    <div class="col-md-6">
									<div class="form-group">
										<input class="form-control" name="mail" id="mail" type="mail" placeholder="Correo electronico"  >
										
									</div>
                                    </div>
                                    
                                    <div class="col-md-6">
									<div class="form-group">
										<input class="form-control" name="conf_mail" id="conf_mail" type="mail" placeholder="Confirmar correo electronico"  >
										
										</div>
                                    </div>
                                    
										<div class="col-md-6">
									<div class="form-group">
										<input class="form-control" name="pass" id="pass" type="password" placeholder="pass" value="123456"  style="visibility:hidden"  >
										
									</div>
                                    </div>
                                    
                                    <div class="col-md-6">
									<div class="form-group">
									    <h5>Fecha de nacimiento</h5>
										<input class="form-control" name="nacimiento" id="nacimiento" type="date" placeholder="Fecha de nacimiento"  >
										
									</div>
                                    </div>
                                    
                                    <div class="col-md-6">
									<div class="form-group">
										<input class="form-control" name="copiloto" id="copiloto" type="text" placeholder="Nombre de copiloto (opcional)" >
										
									</div>
                                    </div>
                                    
                                    <div class="col-md-6">
									<div class="form-group">
										<input class="form-control" name="moto" id="moto" type="text" placeholder="Moto y cilindraje"  >
										
									</div>
                                    </div>
                                   
								
								<div class="col-md-6">
									<div class="form-group">
										<input class="form-control" name="placa" id="placa" type="text" placeholder="Placa"  >
										
									</div>
                                    </div>
                                    
                                    	<div class="col-md-6">
									<div class="form-group">
										<input class="form-control" name="numero" id="numero" type="text" placeholder="Numero (El del buso) "  >
										
									</div>
                                    </div>
                                    
                                    <h5>Datos de contacto Emergencia</h5>
                                    
                                    	<div class="col-md-6">
									<div class="form-group">
										<input class="form-control" name="contacto1" id="contacto1" type="text" placeholder="Nombre"  >
										
									</div>
                                    </div>
                                    
                                    <div class="col-md-6">
									<div class="form-group">
										<input class="form-control" name="telefono1" id="telefono1" type="text" placeholder="Telefono" >
										
									</div>
                                    </div>
								
									
									
									<center><span><input class="form-btn3" name="registro" type="submit" value="Registrar"  class="enviar"/></span></center>
									
								
							
						</form>
						
    

    <!-- ALL JS FILES -->
   <script src="js/all.js"></script>
	<!-- Camera Slider -->
	
	
	
	<!-- Contact form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>
    <div id="ultimo"></div>
</body>
</html>