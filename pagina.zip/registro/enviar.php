<?PHP
$nombre = $_POST['nick'];
$correo = $_POST['mail'];
$telefono = $_POST['telefono'];
$placa= $_POST['placa'];
$moto = $_POST['moto'];

//datos para el correo

$destinatario = "legionbikers@gmail.com";
$asunto = "Nuevo Registro";

$carta = "Buen dia Bikers Legion, estos son los datos del nuevo registro:
Nombre: $nombre \n";
$carta .= "Correo: $correo \n";
$carta .= "Telefono: $telefono \n";
$carta .= "Moto: $moto, $placa,
Gracias por su atencion.";

//enviado mensaje
mail($destinatario,$asunto,$carta);






?>
