<?php
$conex= mysqli_connect("localhost","id13284297_registro1","K7%t?NEs?8e0Bitc","id13284297_registro");
?>