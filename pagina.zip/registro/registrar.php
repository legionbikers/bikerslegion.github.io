<?php
$conex= mysqli_connect("fdb23.atspace.me","3417848_registro","eldesparche123","3417848_registro");



if (isset($_POST['registro'])){

   if (strlen($_POST['nick']) >= 1 && strlen($_POST['telefono']) >= 1) {
            
            $nick = $_POST['nick'];
            $rh= $_POST['rh'];
            $telefono= $_POST['telefono'];
            
            $copiloto= $_POST['copiloto'];
            $moto= $_POST['moto'];
            $placa= $_POST['placa'];
            $numero= $_POST['numero'];
            $contacto1= $_POST['contacto1'];
            $telefono1= $_POST['telefono1'];
            $mail= $_POST['mail'];
            $pass= $_POST['pass'];
            
   
   
   $consulta= "INSERT INTO admin(nick,rh,telefono,copiloto,moto,placa,numero,contacto1,telefono1,mail,pass) VALUES ('$nick','$rh','$telefono','$copiloto','$moto','$placa','$numero','$contacto1','$telefono1','$mail','$pass')";
   $resultado =mysqli_query($conex,$consulta);
   mysqli_close($conex);
   if ($resultado) {
       ?>
       <h3>Te has registrado correctamente en la base de datos de Biker's Legion</h3>
       <?php
   } else {
       ?>
       <h3> Ups! ha ocurrido un error informarlo a administrador de la pagina</h3>
       <?php
   }
   }
       else {
           ?>
           <h3> Porfavor completa los campos</h3>
           
           
       <?php
   }
}


?>