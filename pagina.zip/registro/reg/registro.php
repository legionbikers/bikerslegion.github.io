<?php include('conexion.php'); ?>

<!DOCTYPE html>
<html lang="es">
<head>
	<title>LogIn</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
	<link rel="stylesheet" href="css/sweet-alert.css">
    <link rel="stylesheet" href="css/material-design-iconic-font.min.css">
    <link rel="stylesheet" href="css/normalize.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/jquery.mCustomScrollbar.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/login.css"/>
    
</head>
<body class="full-cover-background" style="background-image:url(assets/img/font-login.jpg);">
    <div class="form-container">
        <p class="text-center" style="margin-top: 17px;">
           <i class="zmdi zmdi-account-circle zmdi-hc-5x"></i>
            </p>
       <h4 class="text-center all-tittles" style="margin-bottom: 30px;">inicia sesión con tu cuenta</h4>
    <form class="full-box logInForm" name="registrar" action="" id="form1" method="post" onSubmit="return validar()" />
    <h6>Ya estÃ¡s registrado?<a href="index.php" > Inicia sesiÃ³n</a></h6>    
   <?php
if(isset($_POST['registro']))//Vallidamos que el formulario fue enviado
{
    /*Validamos que todos los campos esten llenos correctamente*/
    if(($_POST['nick'] != '') && ($_POST['mail'] != '') && ($_POST['pass'] != '') && ($_POST['conf_pass'] != ''))
    {
        if($_POST['pass'] != $_POST['conf_pass'])
        {
            echo '<h5>Las contraseÃ±as no coinciden</h5>';
        }
        else
        {
            $date= time(); 
            $nick= limpiar($_POST['nick']);
            $mail= limpiar($_POST['mail']);
            $pass= limpiar($_POST['pass']);
            $ipuser= $_SERVER['REMOTE_ADDR'];
             
            $b_user= $conexion ->query("SELECT nick FROM admin WHERE nick='$nick'");
            if($user=@mysqli_fetch_array($b_user))
            {
                echo '<h5>El nombre de usuario o el email ya esta registrado.</h5>';
                mysqli_free_result($b_user); //liberamos la memoria del query a la db
            }
            else
            {
                if(validar_email($_POST['mail']))
                {
                    $res=$conexion ->query("INSERT INTO admin (fecha,nick,mail,pass,ip) values ('$date','$nick','$mail','$pass','$ipuser')");
                    echo '<h4>Te has registrado Correctamente, ahora podras iniciar sesiÃ³n como usuario registrado.</h4>';
                }
                else
                {
                    echo '<h5>El email no es valido.</h5>';
                }
            }
        }
    }
    else
    {
        echo '<h5>Deberas llenar todos los campos.</h5>';
    }
}
?>


	 
        <div class="group-material-login">
		  
    <div>
    <label for="login_username"></label> 
        <input class="form-control" type="text" name="nick" id="nick" class="material-login-control" placeholder="Digite Usuario" />
        </div><br>
     <div class="group-material-login">
    <div>
        <label for="login_mail"></label> 
        <input class="form-control" type="text" name="mail" id="mail" class="material-login-control" placeholder="Ingrese su correo" />
     </div><br>          
     <div class="group-material-login">
    
    <div>
        <label for="login_pass"></label> 
        <input class="form-control" type="password" name="pass" id="pass" class="material-login-control" placeholder="Ingrese su contraseÃ±a" />
    </div><br>          
     <div class="group-material-login">
     
    <div>
        <label for="login_conf_pass"></label>
        <input class="form-control" type="password" name="conf_pass" id="conf_pass" class="material-login-control" placeholder="Confirme su contraseÃ±a" />
    </div><br>          
     <div class="group-material-login">
         
         <center><span><input class="btn btn-raised btn-danger" name="registro" type="submit" value="Registrar"  class="enviar"/></span></center>
        

	</form>
   
    </span>
	<script>
		$.material.init();
	</script>
</body>
</html>