<?php
include("conexion.php");
if (isset($_POST['registro'])){

   if (strlen($_POST['nick']) >= 1  && strlen($_POST['telefono']) >= 1  && strlen($_POST['rh']) >= 1) {
  
   $nick = $_POST['nick'];
   
            $telefono= $_POST['telefono'];
              $rh= $_POST['rh'];
           
   
   $consulta = "INSERT INTO prueba(nick,telefono,rh) VALUES ('$nick','$telefono','$rh')";
   $resultado = mysqli_query($conex,$consulta);
   if ($resultado) {
       ?>
       <h3>Te has registrado correctamente en la base de datos de Biker's Legion</h3>
       <?php
   } else {
       ?>
       <h3> Ups! ha ocurrido un error informarlo a administrador de la pagina</h3>
       <?php
   }
   }
       else {
           ?>
           <h3> Porfavor completa los campos</h3>
           
           
       <?php
   }
}
?>