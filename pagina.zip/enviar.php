<?PHP
$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$telefono = $_POST['telefono'];
$mensaje = $_POST['mensaje'];
$asunto = $_POST['asunto'];

//datos para el correo

$destinatario = "legionbikers@gmail.com";
$asunto = "Nuevo comentario";

$carta = "Buen dia Bikers Legion, estos son los datos del nuevo comentario:
Nombre: $nombre \n";
$carta .= "Correo: $correo \n";
$carta .= "Telefono: $telefono \n";
$carta .= "Mensaje: $asunto, $mensaje,
Gracias por su atencion.";

//enviado mensaje
mail($destinatario,$asunto,$carta);

?>
<script>
			alert("Registro Exitoso");
			location.href="index.html";
		</script>
