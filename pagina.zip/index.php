
<html lang="es">

<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Biker's legion</title>
    <meta name="Nova theme" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="assets/images/ttr.png"/>
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="font.css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
          integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
          rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css"/>
    <link rel="stylesheet" href="assets/css/responsive.css"/>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>
<style>
    #ultimo + div{
        visibility: hidden;
    }
</style>
</head>

<body>

<!-- Navigation
    ================================================== -->
<div class="hero-background">
    
    <div class="container">
        <div class="header-container header">
            <a class="navbar-brand logo" href="#"> <img class="logo" src="assets/images/ttr.png"/> 
            </a>
            
            <!--/a>
            <a href="#email-form">
                <button class="header-btn"> Download FREE!</button>
            </a-->
            <div class="header-right">
                
            
            </div>
        </div>
        
        
        
        <!--navigation-->


        <!-- Hero-Section
          ================================================== -->
<br>
</br>

        <center><div class="texto1" id="texto1">
            
                <strong><h1 class="texto1"> Base de datos <br></h1></strong>
                <h2 class="texto2"> Registrate con tus datos para poseer  informacion de los integrantes en caso de cualquier evento.
              </h2>
              </div>
              <a href="http://bikerslegion.atspace.cc/registro/index.php"  class="form-btn3"  type="button">Registrate</a>
       
              <!--button  class="form-btn3"  url="http://bikerslegion.atspace.cc/registro/index.php'">Registrate</button-->

              
                <!--button id="btn-abrir-popup" class="form-btn3">Registrate</button>
                <div class="overlay" id="overlay">
			<div class="popup" id="popup">
				<a href="#" id="btn-cerrar-popup" class="btn-cerrar-popup"><i class="fas fa-times"></i></a>
				<h3>PROXIMAMENTE!!</h3>
				<!--h4>y recibe un cupon de descuento.</h4-->
				<form action="">
					<!--div class="contenedor-inputs">
						<input type="text" placeholder="Nombre">
						<input type="email" placeholder="Correo">
					</div>
					<input class="form-btn3" type="submit"  value="Suscribirse"-->
				</form>
		
	<script src="popup.js"></script>
            </div><!--hero-left--></center>
            </br>
            </br>
         
         
         <center><iframe src="http://bikerslegion.atspace.cc/registro/cumplea%C3%B1os.php" frameborder="0" marginheight="0" marginwidth="0"  width="100%" height="350"> </iframe></center>
         <!--center><iframe src="http://bikerslegion.atspace.cc/registro/galeria/fluid-gallery.php" frameborder="0" marginheight="0" marginwidth="0"  width="100%" height="350"> </iframe></center-->
         
         
<!-- Features
  ================================================== -->

<!--div id="features" class="features-section">

    <div class="features-container row">

        <h2 class="features-headline light">FEATURES</h2>

        <div class="col-sm-4 feature">

            <div class="feature-icon feature-no-display">
                <img class="feature-img" src="assets/images/responsive.svg">
            </div>
            <h5 class="feature-head-text feature-no-display"> FULLY RESPONSIVE </h5>
            <p class="feature-subtext light feature-no-display"> Looks amazing on any
                device: smartphone, tablet, laptop and desktop.</p>
        </div>

        <div class="col-sm-4 feature">
            <div class="feature-icon feature-no-display feature-display-mid">
                <img class="feature-img" src="assets/images/customizable.svg">
            </div>
            <h5 class="feature-head-text feature-no-display feature-display-mid"> CUSTOMIZABLE </h5>
            <p class="feature-subtext light feature-no-display feature-display-mid"> Change the colors, pictures or any
                of the sections
                to suit your needs.</p>
        </div>

        <div class="col-sm-4 feature">
            <div class="feature-icon feature-no-display feature-display-last">
                <img class="bullet-img" src="assets/images/design.svg">
            </div>
            <h5 class="feature-head-text feature-no-display feature-display-last"> SLICK AND BEAUTIFUL DESIGN </h5>
            <p class="feature-subtext light feature-no-display feature-display-last"> Trendy and fresh design, fits any
                website.</p>
        </div>
    </div> <!--features-container-->
 <!--features-section-->

<!-- Logos
  ================================================== -->

<!--div class="logos-section">
    <img class="logos" src="assets/images/logos.png"/>
</div><!--logos-section-->

<!-- White-Section
  ================================================== -->

<!--div class="white-section row">

    <div class="imac col-sm-6">
        <img class="imac-screen img-responsive" src="assets/images/imac.png">
    </div>
    <!--imac-->

    <!--div class="col-sm-6">

        <div class="white-section-text">

            <h2 class="imac-section-header light">SIMPLE AND BEAUTIFUL</h2>

            <div class="imac-section-desc">

            <span>  Use Nova theme for your next web project.
                It is completely customizable so you can change any of the sections to fit your needs.
                Nova Theme is Free for any kind of use, personal and commercial. Have fun and good luck!</span>
            </div>
        </div>
    </div>
</div><!--white-section-text-section--->


<!-- Pricing
  ================================================== -->
<!--div id="pricing" class="pricing-background">

    <h2 class="pricing-section-header light text-center">CHOOSE YOUR PRICING PLAN</h2>
    <h4 class=" pricing-section-sub text-center light">Pick any of our super affordable pricing plans</h4>

    <div class="pricing-table row">
        <div class="col-sm-4">
            <div class="plan">
                <h3 class="plan-title light">BASIC</h3>
                <h4 class="plan-cost bold">15</h4>
                <h5 class="monthly">per month</h5>
                <ul class="plan-features">
                    <li>Up to 7 Projects</li>
                    <li>2 Additional Developers</li>
                </ul>
                <div class="plan-price-div text-center">
                    <div class="choose-plan-div">
                        <a class="plan-btn light" href="#">
                            Get Started
                        </a>
                    </div>
                </div>
            </div><!--basic-plan--->
        <!--/div><!--col-->

        <!--div class="col-sm-4">
            <div class="mid-plan">
                <h3 class="plan-title light">AGENCY</h3>
                <h4 class="plan-cost bold">55</h4>
                <h5 class="monthly">per month</h5>
                <ul class="plan-features">
                    <li>Up to 25 Projects</li>
                    <li>2 Additional Developers</li>
                    <li>Unlimited Support</li>
                </ul>
                <div class="plan-price-div text-center">
                    <div class="choose-plan-div">
                        <a class="plan-btn light" href="#">
                            Get Started
                        </a>
                    </div>
                </div>
            </div><!--pro-plan--->
        <!--/div><!--col-->

        <!--div class="col-sm-4">
            <div class="plan">
                <h3 class="plan-title light">PRO</h3>
                <h4 class="plan-cost bold">75</h4>
                <h5 class="monthly">per month</h5>
                <ul class="plan-features">
                    <li>Up to 25 Projects</li>
                    <li>2 Additional Developers</li>
                    <li>Unlimited Support</li>
                    <li>1.5GB Disk Space</li>
                </ul>
                <div class="plan-price-div text-center">
                    <div class="choose-plan-div">
                        <a class="plan-btn light" href="#">
                            Get Started
                        </a>
                    </div>
                </div>
            </div><!--pro-plan--->
        <!--/div><!--col-->

    <!--/div>  <!--pricing-table-->

<!--/div><!--pricing-background-->

<!-- Team
  ================================================== -->

<!--div id="team" class="team">
    <h2 class="team-section-header light text-center">THE TEAM</h2>

    <div class="team-container row">


        <div class="col-sm-4 team-member">
            <img src="assets/images/cto.png">
            <div class="team-member-text">
                <h4 class="team-member-position light">CTO</h4>
                <h5 class="bold">Johnny B Good</h5>
                <p class="light">The brains behind the whole operation</p>
                <a href="http://www.twitter.com"><img class="team-social-icon" src="assets/images/team-twitter.svg"></a>
                <a href="http://www.facebook.com"><img class="team-social-icon"
                                                       src="assets/images/team-facebook.svg"></a>
                <a href="https://plus.google.com/"><img class="team-social-icon"
                                                        src="assets/images/team-google.svg"></a>
            </div>
        </div>

        <div class="col-sm-4 team-member">
            <img src="assets/images/ceo.png">
            <div class="team-member-text">
                <h4 class="team-member-position light">CEO</h4>
                <h5 class="bold">Roll Over Beethoven</h5>
                <p class="light">The one that puts it all together </p>
                <a href="http://www.twitter.com"><img class="team-social-icon" src="assets/images/team-twitter.svg"></a>
                <a href="http://www.facebook.com"><img class="team-social-icon"
                                                       src="assets/images/team-facebook.svg"></a>
                <a href="https://plus.google.com/"><img class="team-social-icon"
                                                        src="assets/images/team-google.svg"></a>
            </div>
        </div>

        <div class="col-sm-4 team-member">
            <img src="assets/images/cfo.png">
            <div class="team-member-text">
                <h4 class="team-member-position light">CFO</h4>
                <h5 class="bold">Chuck Berry</h5>
                <p class="light">The guy with his hand on the wallet</p>
                <a href="http://www.twitter.com"><img class="team-social-icon" src="assets/images/team-twitter.svg"></a>
                <a href="http://www.facebook.com"><img class="team-social-icon"
                                                       src="assets/images/team-facebook.svg"></a>
                <a href="https://plus.google.com/"><img class="team-social-icon"
                                                        src="assets/images/team-google.svg"></a>
            </div>

        </div>
        <! -- .row -->


    <!--team-section--->

<!-- Email-Section
  ================================================== -->

<div class="blue-section">
    <h3 class="blue-section-header bold"> Envianos tus comentarios</h3>
    <h4 class="blue-section-subtext light">Cambios en el club, proximos destinos, opiniones, problemas etc</h4>

    
                    
                       <center> <form id="contact" action="enviar.php" method="post">
                            <div class="row">
                                <div class="col-md-6">
                                
                                  <fieldset>
 <label for="names">Nombres * </label>
 <input  class="controls2" type="text"  id="names" name="nombre" required>
                                  </fieldset>
                                </div>
                                <div class="col-md-6">
                                  <fieldset>
 <label for="phone">Telefono o Celular * </label>
 <input class="controls2" type="text"  id="phone" name="telefono"  required>
                                  </fieldset>
                                </div>
                                 <div class="col-md-6">
                                  <fieldset>
 <label for="email">Correo electronico *</label>
 <input class="controls2" type="email"  id="email" name="correo" required>
                                  </fieldset>
                                </div>
                                <div class="col-md-6">
                                <fieldset>
 <label for="asunto">Asunto *</label>
 <input class="controls2" type="text"  id="asusto" name="asunto"  placeholder="Rodadas(Destinos), Quejas, Dudas..." required>
                                  </fieldset>
                                </div>
                                <div class="col-md-6">
                                  <fieldset>
 <label for="mensaje">Mensaje *</label>
 <textarea class="controls2" id="mensaje" name="mensaje" required></textarea>
                                  </fieldset>
                               
                                </div>
                                
                                
                                <div class="col-md-12">
                                  <fieldset>
 <input class="form-btn3" type="submit" id="btnsent" value="Enviar Mensaje">
                                  </fieldset>
                                </div>
                            </div>
                            
                        </form>
    

        </div>
        
<!--footer-->

<script src="https://code.jquery.com/jquery-3.2.1.min.js"
        integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
        crossorigin="anonymous"></script>

<script src="assets/js/script.js"></script>



     <div class="social-bar">
    <a href="https://www.facebook.com/BiikersLegion" class="icon icon-facebook" target="_blank"></a>
   
    <a href="https://www.instagram.com/bikers_legion" class="icon icon-instagram" target="_blank">
        <a href="https://api.whatsapp.com/send?phone=573102907316&text=Buen%20dia,%20vengo%20de%20la%20pagina%20bikerslegion%20y%20quiero%20hacerle%20una%20pregunta" class="icon icon-whatsapp" target="_blank"></a>
    </a></div>

<div id="ultimo"></div>
</body>

</html>